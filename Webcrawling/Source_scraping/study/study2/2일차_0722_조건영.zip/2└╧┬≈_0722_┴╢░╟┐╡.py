# 할리스 매장정보 찾기

# 모듈
from bs4 import BeautifulSoup
from urllib.request import urlopen
import pandas as pd

# 할리스 매장 정보 추출하는 함수
def hallris_clean():
    branch_re=[] # 매장 지역
    branch_na=[] # 매장 이름
    branch_add=[] # 매장 주소
    branch_tel=[] # 매장 번호
    for i in range(54):
        page='https://www.hollys.co.kr/store/korea/korStore2.do?pageNo='+str(i)+'&sido=&gugun=&store='
        html=urlopen(page)
        bs=BeautifulSoup(html,'html.parser')

        branchs_data=bs.select('tbody tr')
        for branch_data in branchs_data:
            want_branch_data=branch_data.select('td.center_t')
            branch_re.append(want_branch_data[0].text)
            branch_na.append(want_branch_data[1].text)
            branch_add.append(want_branch_data[3].text)
            branch_tel.append(want_branch_data[5].text)
    return branch_re,branch_na,branch_add,branch_tel

# 매장 위치를 찾는 함수
def region_find(hallris_df,region):
    i=0
    result=[]
    for idx in range(len(hallris_df)):
        if region in hallris_df['매장이름'][idx]:
            i+=1
            result.append(f"[{i:3}]: [{hallris_df['주소'][idx]}, {hallris_df['전화번호'][idx]}]")
    print('-------------------------------------')
    print(f"검색된 매장 수 : {i}")
    print('-------------------------------------')
    for i in result:
        print(i)

# 실행
branch_re,branch_na,branch_add,branch_tel=hallris_clean()

# 데이터 프레임 만들기
hallris_df=pd.DataFrame([branch_re,branch_na,branch_add,branch_tel],index=['매장이름','위치(시,구)','주소','전화번호']).T

# csv 파일 만들기
hallris_df.to_csv('hollys_branches.csv',encoding='utf-8-sig',index=False)

# csv파일 읽기
hallris_csv_df=pd.read_csv('hollys_branches.csv',encoding='utf-8-sig')
print(hallris_csv_df)

# 1번 화면출력
for r in range(len(hallris_csv_df)):
    print(f"[{r+1:3}]: 매장이름: {hallris_csv_df.loc[r,'매장이름']}, 지역: {hallris_csv_df.loc[r,'위치(시,구)']}, 주소: {hallris_csv_df.loc[r,'주소']}, 전호번호: {hallris_csv_df.loc[r,'전화번호']}")
print()
print(f"전체 매장 수 : {len(hallris_csv_df)}")

# 2번 화면출력
region=input('검색할 매장의 도시를 입력하세요: ')
region_find(hallris_csv_df,region)


